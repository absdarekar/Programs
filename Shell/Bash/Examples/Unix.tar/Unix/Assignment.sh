#mkdir -p ~/Unix/dir1 ~/Unix/dir2
#cd ~/Unix/dir1
#touch myFile
#cat > myFile 
#cp ./myFile ../dir2/myFile
#cd ../dir2
#cat >> myFile 
#mv myFile newFile
wc -l < ~/Unix/dir1/myFile
who -u
grep -i "this" ~/Unix/dir1/myFile | wc -l
sed 's/this/that/g' ~/Unix/dir1/myFile 
sed 's/this/that/' ~/Unix/dir1/myFile 
head -3 ~/Unix/dir1/myFile 
tail -3 ~/Unix/dir1/myFile 
sed '1 s/^/Append a new line in the beginning of the file\n/' ~/Unix/dir1/myFile 
#cat > student.txt
awk 'BEGIN {FS="|"};{print $2, $1}' ~/Unix/dir1/student.txt 
awk 'BEGIN {FS="|"}; NR>1 {print $2"-"$3+$4+$5}' ~/Unix/dir1/student.txt 
